# Bootcamp-Engenharia-de-Dados
Bootcamp Banco Carrefour Data Engineer
Bootcamp de engenharia de dados do carrefour na Digital Inovation One
Codigos de estudo e containeres de projetos praticos
